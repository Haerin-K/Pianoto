import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class OutfitButton extends Actor
{
    private VocaloidCharacter characterRef;
    
    public OutfitButton(VocaloidCharacter character) {
        this.characterRef = character;
        setImage(new GreenfootImage("Outfit", 24, Color.WHITE, Color.BLACK));
    }
    
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            characterRef.changeOutfit(1);
        }
    }
}
