import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class VocaloidCharacter extends Actor
{
    private String[] outfitImages = {"defaultTeto.png"};
    private int currentOutfitIndex = 0;
    
    private final int CHARACTER_WIDTH = 600;
    private final int CHARACTER_HEIGHT = 350;
    
    public VocaloidCharacter() {
        setImageAndScale(outfitImages[currentOutfitIndex]);
    }
    
    public void act() {
        
    }
    
    private void setImageAndScale(String fileName) {
        GreenfootImage img = new GreenfootImage(fileName);
        
        img.scale(CHARACTER_WIDTH, CHARACTER_HEIGHT);
        
        setImage(img);
    }
    
    public void changeOutfit(int direction) {
        currentOutfitIndex += direction;
        
        if (currentOutfitIndex < 0) {
            currentOutfitIndex = outfitImages.length - 1;
        } else if (currentOutfitIndex == outfitImages.length) {
            currentOutfitIndex = 0;
        }
        
        setImageAndScale(outfitImages[currentOutfitIndex]);
    }
}
