import greenfoot.*;

/**
 * A piano key that plays a sound when pressed and stops shortly after release.
 */
public class PianoKey extends Actor
{
    private String key;
    private GreenfootSound sound;
    private boolean isPressed;
    private boolean isReleased;
    private int releaseTimer;

    public PianoKey(String key, String soundFile, String imageType) {
        // Set key image depending on type
        if (imageType.equalsIgnoreCase("black")) {
            setImage("blackkey.png");
        } else {
            setImage("whitekey.png");
        }

        this.key = key;
        this.sound = new GreenfootSound(soundFile);
        this.isPressed = false;
        this.isReleased = false;
        this.releaseTimer = 0;
    }

    public void act() {
        if (Greenfoot.isKeyDown(key)) {
            if (!isPressed) {
                sound.play();      // Play sound once
                isPressed = true;
                isReleased = false;
                releaseTimer = 0;
            }
        } else {
            if (isPressed && !isReleased) {
                isReleased = true;
                releaseTimer = 0;
            }

            if (isReleased) {
                releaseTimer++;
                if (releaseTimer >= 18) { // ~0.6 seconds (assuming 30 FPS)
                    sound.stop();
                    isPressed = false;
                    isReleased = false;
                    releaseTimer = 0;
                }
            }
        }
    }
}