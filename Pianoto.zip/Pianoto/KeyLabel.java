import greenfoot.*;
import java.awt.Font;
import greenfoot.Color;

public class KeyLabel extends Actor
{
    public KeyLabel(String text)
    {
        // Define the visual style for the text
        int fontSize = 16;
        greenfoot.Color textColor = greenfoot.Color.BLACK;
        greenfoot.Color backgroundColor = new greenfoot.Color(0, 0, 0, 0); // Transparent background
        
        // Create a GreenfootImage from the text
        GreenfootImage img = new GreenfootImage(text, fontSize, textColor, backgroundColor);
        
        // Optionally, make the text bold or change the font
        img.setFont(img.getFont().deriveFont(Font.BOLD));
        
        setImage(img);
    }
}