import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class PianoWorld extends World
{
    private String[] backgroundImages = {"sakura1.png", "nature1.jpg"};
    private int currentBackgroundIndex = 0;
    
    private VocaloidCharacter character;

    public PianoWorld() {
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1);

        // Set background image
        GreenfootImage initialBG = new GreenfootImage(backgroundImages[currentBackgroundIndex]);
        
        initialBG.scale(getWidth(), getHeight());
        
        setBackground(initialBG);

        prepare();
    }
    
    public void act() {
        
    }

    private void prepare() {
        // Add Teto character
        character = new VocaloidCharacter();
        addObject(character, 300, 200);
        
        // Add outfit change button
        OutfitButton outfitButton = new OutfitButton(character);
        addObject(outfitButton, 50, 50);
        
        // Add background change button
        BackgroundButton backgroundButton = new BackgroundButton();
        addObject(backgroundButton, 82, 100);
        
        // White keys (lower row)
        addObject(new PianoKey("q", "teto-C3_MixDown.wav", "white"), 50, 333);
        addObject(new KeyLabel("q"), 50, 363);
        addObject(new PianoKey("w", "teto-D3_MixDown.wav", "white"), 75, 333);
        addObject(new KeyLabel("w"), 75, 363);
        addObject(new PianoKey("e", "teto-E3_MixDown.wav", "white"), 100, 333);
        addObject(new KeyLabel("e"), 100, 363);
        addObject(new PianoKey("r", "teto-F3_MixDown.wav", "white"), 125, 333);
        addObject(new KeyLabel("r"), 125, 363);
        addObject(new PianoKey("t", "teto-G3_MixDown.wav", "white"), 150, 333);
        addObject(new KeyLabel("t"), 150, 363);
        addObject(new PianoKey("y", "teto-A3_MixDown.wav", "white"), 175, 333);
        addObject(new KeyLabel("y"), 175, 363);
        addObject(new PianoKey("u", "teto-B3_MixDown.wav", "white"), 200, 333);
        addObject(new KeyLabel("u"), 200, 363);
        addObject(new PianoKey("", "", "white"), 225, 333);
        addObject(new PianoKey("", "", "white"), 250, 333);
        addObject(new PianoKey("", "", "white"), 275, 333);
        addObject(new PianoKey("", "", "white"), 300, 333);
        addObject(new PianoKey("", "", "white"), 325, 333);
        addObject(new PianoKey("", "", "white"), 350, 333);
        addObject(new PianoKey("", "", "white"), 375, 333);
        addObject(new PianoKey("", "", "white"), 400, 333);
        addObject(new PianoKey("", "", "white"), 425, 333);
        addObject(new PianoKey("", "", "white"), 450, 333);
        addObject(new PianoKey("", "", "white"), 475, 333);
        addObject(new PianoKey("", "", "white"), 500, 333);
        addObject(new PianoKey("", "", "white"), 525, 333);
        addObject(new PianoKey("", "", "white"), 550, 333);

        // Black keys (slightly higher row)
        addObject(new PianoKey("i", "teto-Cs3_MixDown.wav", "black"), 60, 314);
        addObject(new BlackKeyLabel("i"), 60, 329);
        addObject(new PianoKey("o", "teto-Ds3_MixDown.wav", "black"), 90, 314);
        addObject(new BlackKeyLabel("o"), 90, 329);
        addObject(new PianoKey("", "", "black"), 235, 314);
        addObject(new PianoKey("", "", "black"), 265, 314);
        addObject(new PianoKey("", "", "black"), 410, 314);
        addObject(new PianoKey("", "", "black"), 440, 314);
        // Skip between E and F (no black key)
        addObject(new PianoKey("p", "teto-Fs3_MixDown.wav", "black"), 135, 314);
        addObject(new BlackKeyLabel("p"), 135, 329);
        addObject(new PianoKey("a", "teto-Gs3_MixDown.wav", "black"), 163, 314);
        addObject(new BlackKeyLabel("a"), 163, 329);
        addObject(new PianoKey("s", "teto-As3_MixDown.wav", "black"), 190, 314);
        addObject(new BlackKeyLabel("s"), 190, 329);
        addObject(new PianoKey("", "", "black"), 310, 314);
        addObject(new PianoKey("", "", "black"), 338, 314);
        addObject(new PianoKey("", "", "black"), 365, 314);
        addObject(new PianoKey("", "", "black"), 485, 314);
        addObject(new PianoKey("", "", "black"), 513, 314);
        addObject(new PianoKey("", "", "black"), 540, 314);
    }
    
    public void changeBackground(int direction) {
        currentBackgroundIndex += direction;
        
        if (currentBackgroundIndex < 0) {
            currentBackgroundIndex = backgroundImages.length - 1;
        } else if (currentBackgroundIndex == backgroundImages.length) {
            currentBackgroundIndex = 0;
        }
        
        GreenfootImage newBackground = new GreenfootImage(backgroundImages[currentBackgroundIndex]);
        
        int worldWidth = getWidth();
        int worldHeight = getHeight();
        
        newBackground.scale(worldWidth, worldHeight);
        
        setBackground(newBackground);
    }
}
