import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class BackgroundButton extends Actor
{
    public BackgroundButton() {
        setImage(new GreenfootImage("Background", 24, Color.WHITE, Color.DARK_GRAY));
    }
    
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            PianoWorld world = (PianoWorld)getWorld();
            
            world.changeBackground(1);
        }
    }
}
